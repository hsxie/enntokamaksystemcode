% Hua-sheng XIE, huashengxie@gmail.com, 2018-11-22 13:37
% Ref: [1] Bosch & Hale, 1992, fusion cross-sections
% [2] Nevins & Swain, 2000, p- 11 B
% 2020-04-15 23:42 rewrite to function
% 22-03-15 12:35 add range 0.9-4.8MeV
% 22-11-28 15:55 fixed bug for E>900keV

function sigmadhe=fsgmdhe(E)

% E=10.^(0:0.002:3.0); % keV

% 4. D + He3 -> p + He4 + 18.2MeV, 

% ind1=find(abs(E-900)==min(abs(E-900)));
% % ind1=find(abs(E-9000)==min(abs(E-9000)));
% E1=E(1:ind1); E2=E((ind1+1):end);


ind1=find(E<900); ind2=find(E>=900 & E<=4800);
E1=E(ind1); E2=E(ind2);


% 0.3-900 keV, S_error<2.2%
BGdhe  =  68.7508;
Adhe1   =  [5.7501e6,    2.5226e3,    4.5566e1,    0.0,   0.0  ];
Bdhe1   =  [-3.1995e-3,  -8.5530e-6,  5.9014e-8,   0.0          ];
Sdhe1=(Adhe1(1)+Adhe1(2)*E1+Adhe1(3)*E1.^2+Adhe1(4)*E1.^3+Adhe1(5)*E1.^4)./(1.0+...
    Bdhe1(1)*E1+Bdhe1(2)*E1.^2+Bdhe1(3)*E1.^3+Bdhe1(4)*E1.^4);

% 900-4800 keV, S_error<1.2%
Adhe2   =  [-8.3993e5,   0.0  ];
Bdhe2   =  [-2.6830e-3,  1.1633e-6,  -2.1332e-10,   1.4250e-14          ];
Sdhe2=(Adhe2(1))./(1.0+...
    Bdhe2(1)*E2+Bdhe2(2)*E2.^2+Bdhe2(3)*E2.^3+Bdhe2(4)*E2.^4);
% Sdhe=[Sdhe1,Sdhe2];
% sigmadhe=Sdhe./(E.*exp(BGdhe./sqrt(E)))*1e-31; % unit: mb (1e-31 m^2) -> m^-2

Sdhe=0.*E;  % 22-11-16 08:27 to check use 0 or NaN
Sdhe(ind1)=Sdhe1;
Sdhe(ind2)=Sdhe2;
sigmadhe=Sdhe./(E.*exp(BGdhe./sqrt(E)))*1e-31; % unit: mb (1e-31 m^2) -> m^2

% sigmadhe(E>4800 | E<0.3)=NaN;
