% Hua-sheng XIE, huashengxie@gmail.com, ENN, 2022-05-16 15:37
% Scan funsc() in two parameters space, with fixed tauE and Ip
% 17:08 can run, to check Qfus, Pbrem, etc

% 22-10-07 09:27 for ENN
% 22-10-07 19:33 for EXL-50U
% 22-11-16 16;05 for EHL

% 25-04-04 16:05 recheck ENN roadmap paper parameters [Liu2024, PoP]

close all; clear; clc;

%jscan     1    2   3       4       5    6    7      8    9     10      11
inputstr={'R0','A','kappa','delta','Sn','ST','ni0','Ti0','BT0','Ip',...
    'tauE','fHe','fimp','Zimp','Rw','g','fT','fsig','f1'};
inputlabel={'R_0[m]','A','\kappa','\delta','S_n','S_T','n_{i0}[m^{-3}]',...
    'T_{i0}[keV]','B_{T0}[T]','I_p[MA]','\tau_E[s]','f_{He}','f_{imp}',...
    'Z_{imp}','R_w','g','f_T','f_\sigma','f_1'};
inputrange={0.5:0.025:1.0; % 1. R0[m]
    1.5:0.1:3.5; % 2. A
    1.0:0.05:2.5; % 3. kappa
    0:0.05:0.3; % 4. delta
    0.3:0.1:2.0; % 5. Sn
    0.3:0.1:3.0; % 6. ST
    (0.1:0.05:1.0)*6e20; % 7. ni0[m^-3]
    (4:2:50)*4; % 8. Ti0[keV]
    0.4:0.05:1.5; % 9. BT0[T]
    0.2:0.05:1.0; % 10. Ip
    0.005:0.005:0.1; % 11. tauE[s]
    0.0:0.01:0.1; % 12. fHe
    0.0:0.01:0.1; % 13. fimp
    1:0.5:10.0; % 14. Zimp
    0.5:0.05:1.0; % 15. Rw
    0.0:0.02:0.1; % 16. g
    0.1:0.1:1.0; % 17. fT
    1.0:0.5:5.0; % 18. fsig
    0.1:0.1:1.0; % 19. f_1
    };
%%

% choose which two parameters to scan
jscanx=8;
jscany=7;

x=inputrange{jscanx};
y=inputrange{jscany};
[xx,yy]=ndgrid(x,y);
[dimx,dimy]=size(xx);

ff=zeros(25,dimx,dimy);
ff(1,:,:)=xx;
ff(2,:,:)=yy;

jpar=3;
% set parameters
if(jpar==0) % ITER 
  % Note slight difference from Costely15, e.g, reactivity, fHe=nHe/ni 
  % not nHe/ne, etc.
    
    icase=1; % D-T

    BT0=5.18; % T
    R0=6.35; % m
    A=3.43;
    kappa=1.86; % elongation
    delta=0.5; % triangularity
    Sn=0.5; % exponents of the density profiles
    ST=1.0; % exponents of the temperature profiles
    Ip=9.2; % MA
    tauE=2.0; % s
    ni0=0.681e20; % m^-3
    Ti0=25; % keV
    
    fHe=0.04; % helium fraction
    fimp=0.01; % impurity ion
    Zimp=10; % impurity ion fraction
    Rw=0.7; % wall reflectivity to cyclotron radiation
    g=0.05; % plasma wall gap
    
    fT=1.0;
    fsig=1.0;
    f1=0.5;
elseif(jpar==1) % for CT, 25-04-04 07:49 recheck 2022-05-30 parameters
    
    icase=5; % p-B11 

    BT0=12.0; % T
    R0=4.0; % m
    A=3.5;
    kappa=2.5; % elongation
    delta=0.5; % triangularity
    Sn=2.0; % exponents of the density profiles
    ST=2.0; % exponents of the temperature profiles
    Ip=15; % MA
    tauE=5; % s
    ni0=5e20; % m^-3
    Ti0=100; % keV
    
    fHe=0.0; % helium fraction
    fimp=0.0; % impurity ion
    Zimp=10; % impurity ion fraction
    Rw=0.95; % wall reflectivity to cyclotron radiation
    g=0.0; % plasma wall gap
    
    fT=0.25;
    fsig=5.0;
    f1=0.9;
elseif(jpar==2) % for ST, 25-04-04 07:49 recheck 2022-05-30 parameters
        
    icase=5; % p-B11 

    BT0=2.6; % T
    R0=3.2; % m
    A=1.7;
    kappa=3.3; % elongation
    delta=0.6; % triangularity
    Sn=2.0; % exponents of the density profiles
    ST=2.0; % exponents of the temperature profiles
    Ip=22; % MA
    tauE=19.3; % s
    ni0=2e20; % m^-3
    Ti0=100; % keV
    
    fHe=0.0; % helium fraction
    fimp=0.0; % impurity ion
    Zimp=10; % impurity ion fraction
    Rw=0.95; % wall reflectivity to cyclotron radiation
    g=0.0; % plasma wall gap
    
    fT=0.25;
    fsig=5.0;
    f1=0.9;
elseif(jpar==3) % for EHL-3B, 25-04-04 16:01 recheck 2022 parameters
        
    icase=5; % p-B11 

    BT0=4.0; % T
    R0=3.2; % m
    A=1.7;
    kappa=2.5; % elongation
    delta=0.6; % triangularity
    Sn=2.0; % exponents of the density profiles
    ST=2.0; % exponents of the temperature profiles
    Ip=25; % MA
    tauE=25; % s
    ni0=2.5e20; % m^-3
    Ti0=140; % keV
    
    fHe=0.0; % helium fraction
    fimp=0.0; % impurity ion
    Zimp=10; % impurity ion fraction
    Rw=0.95; % wall reflectivity to cyclotron radiation
    g=0.0; % plasma wall gap
    
    fT=0.25;
    fsig=2.0;
    f1=0.9;
elseif(jpar==4) % for EHL-3A, 24-06-06 08:05
    
    icase=4; % p-B11 / D-T

    BT0=4.0; % T
    R0=2.0; % m
    A=1.8;
    kappa=2.5; % elongation
    delta=0.6; % triangularity
    Sn=2.0; % exponents of the density profiles
    ST=2.0; % exponents of the temperature profiles
    Ip=10; % MA
    tauE=5; % s
    ni0=1.5e20; % m^-3
    Ti0=70; % keV
    
    fHe=0.0; % helium fraction
    fimp=0.0; % impurity ion
    Zimp=10; % impurity ion fraction
    Rw=0.95; % wall reflectivity to cyclotron radiation
    g=0.0; % plasma wall gap
    
    fT=1/3;
    fsig=1.0;
    f1=0.9;
elseif(jpar==5) % one of EHL-2 design parameters, [Liang2025, PST]
    if(1==1) % EHL-2 D-T equivalent
    icase=1; % D-T

    BT0=3.0; % T
    R0=1.05; % m
    A=1.85;
    kappa=2.2; % elongation
    delta=0.5; % triangularity
    Sn=0.4; % exponents of the density profiles
    ST=0.8; % exponents of the temperature profiles
    Ip=3.0; % MA
    tauE=0.5; % s
    ni0=1.3e20; % m^-3
    Ti0=30; % keV
    
    fHe=0.02; % helium fraction
    fimp=0.01; % impurity ion
    Zimp=10; % impurity ion fraction
    Rw=0.95; % wall reflectivity to cyclotron radiation
    g=0.0; % plasma wall gap
    
    fT=1/3;
    fsig=1.0;
    f1=0.5;
    else % 22-12-16 09:03 p-B
    icase=4; % p-B11

    BT0=3.0; % T
    R0=1.05; % m
    A=1.85;
    kappa=2.2; % elongation
    delta=0.5; % triangularity
    Sn=0.4; % exponents of the density profiles
    ST=0.8; % exponents of the temperature profiles
    Ip=3.0; % MA
    tauE=0.5; % s
    ni0=1.2e20; % m^-3
    Ti0=30; % keV
    
    fHe=0.02; % helium fraction
    fimp=0.01; % impurity ion
    Zimp=10; % impurity ion fraction
    Rw=0.95; % wall reflectivity to cyclotron radiation
    g=0.0; % plasma wall gap
    
    fT=1/3;
    fsig=1.0;
    f1=0.95;
    end
end

eval(['x00=',inputstr{jscanx},';']);
eval(['y00=',inputstr{jscany},';']);

%% scan
for jdimx=1:dimx
    for jdimy=1:dimy
        jdimx
        jdimy
        
        eval([inputstr{jscanx},'=xx(jdimx,jdimy);']);
        eval([inputstr{jscany},'=yy(jdimx,jdimy);']);
        
        [Eth,H98,HST,Pheat,Pn,Pfus,Pwall,Qfus,betaN,betaT,nbar_o_nGw,q,...
            Pbrem,Pcycl,Vp,betap,fTavg,fnavg,Sp,ne0,M]=...
            funsc(R0,A,kappa,delta,Sn,ST,ni0,Ti0,fT,fsig,...
            f1,BT0,Ip,tauE,fHe,fimp,Zimp,Rw,g,icase);
        
        ff(3,jdimx,jdimy)=Eth;
        ff(4,jdimx,jdimy)=H98;
        ff(5,jdimx,jdimy)=Pheat;
        ff(6,jdimx,jdimy)=Pfus;
        ff(7,jdimx,jdimy)=Qfus;
        ff(8,jdimx,jdimy)=betaN;
        ff(9,jdimx,jdimy)=betaT;
        ff(10,jdimx,jdimy)=nbar_o_nGw;
        ff(11,jdimx,jdimy)=q;
        ff(12,jdimx,jdimy)=Pn;
        ff(13,jdimx,jdimy)=Pbrem;
        ff(14,jdimx,jdimy)=Pcycl;
        ff(15,jdimx,jdimy)=Vp;
        ff(16,jdimx,jdimy)=betap;
        ff(17,jdimx,jdimy)=fTavg;
        ff(18,jdimx,jdimy)=fnavg;
        ff(19,jdimx,jdimy)=Pwall;
        ff(20,jdimx,jdimy)=Sp;
        ff(21,jdimx,jdimy)=ne0;
        ff(22,jdimx,jdimy)=M;
        ff(23,jdimx,jdimy)=HST;
        
    end
end
ff0=ff;
%% plot

close all;
h=figure('unit','normalized','Position',[0.03 0.06 0.55 0.8],...
    'DefaultAxesFontSize',13);

pltstr={'E_{th}[MJ]','H_{98}','P_{heat}=P_{\alpha}+P_{heat}[MW]',...
    'P_{fus}[MW]','Q_{fus}','\beta_N',...
    '\beta_T','n_{avg}/n_{Gw}','q','P_{n}[MW]','P_{brem}[MW]','P_{cycl}[MW]',...
    'V_p[m^{3}]','\beta_p','fT_{avg}','fn_{avg}','P_{wall}[MW/m^2]'};

ff=ff0;
ff(imag(ff0)~=0)=NaN+1i*NaN;

Pheatmax=100.0;
Pfusmin=10.0;
Qmin=1.0;
n0max=1.0;

ax1=axes('position',[0.14,0.1,0.8,0.77]);
[CPfus,~]=contour(xx,yy,squeeze(ff(6,:,:)),[1,10,50,Pfusmin,100,500,1000],...
    'linewidth',2,'showtext','on','Color','b');hold on; % Pfus
%     cxx=[CPfus(1,1+(1:CPfus(2,1))),max(max(xx))];cyy=[CPfus(2,1+(1:CPfus(2,1))),max(max(yy))];

[CnG,~]=contour(xx,yy,squeeze(ff(10,:,:)),[1.0,n0max,0.5],...
    'linewidth',2,'showtext','on','Color','k');hold on; % nbar/nG
%     cxx2=[CnG(1,1+(1:CnG(2,1))),max(max(xx))];cyy2=[CnG(2,1+(1:CnG(2,1))),max(max(yy))];
%     cxx=[cxx,CnG(1,1+(1:CnG(2,1)))];cyy=[cyy,CnG(2,1+(1:CnG(2,1)))];

contour(xx,yy,real(squeeze(ff(7,:,:))),[0.01,0.1,Qmin,10,100],...
    'linewidth',3,'showtext','on','Color','g');hold on; % Qfus

contour(xx,yy,real(squeeze(ff(9,:,:))),[0.01,0.1,0.5,1],...
    'linewidth',2,'showtext','on','Color','c');hold on; % betaT

contour(xx,yy,real(squeeze(ff(8,:,:))),[1,3,10],...
    'linewidth',2,'showtext','on','Color','y');hold on; % betaN

contour(xx,yy,real(squeeze(ff(5,:,:))),[5,10,50,Pheatmax,100],...
    'linewidth',2,'showtext','on','Color','r');hold on; % Pheat


contour(xx,yy,real(squeeze(ff(4,:,:))),[0.5,1,2,5,10],...
    'linewidth',2,'showtext','on','Color','m');hold on; % H98
contour(xx,yy,real(squeeze(ff(23,:,:))),[0.5,1,2,5,10],...
    'linewidth',2,'showtext','on','Color','m','linestyle','--');hold on; % HST

%     ind=find(squeeze(ff(10,:,:))<=1 & squeeze(ff(6,:,:))>=50 ...
%         & real(squeeze(ff(7,:,:)))>=1 & real(squeeze(ff(5,:,:)))<=40);
%     strok='n_{avg}/n_G<1, P_{fus}>50, P_{heat}<40, Q>1';
ind=find(squeeze(ff(10,:,:))<=n0max & squeeze(ff(6,:,:))>=Pfusmin ...
    & real(squeeze(ff(7,:,:)))>=Qmin & real(squeeze(ff(5,:,:)))<=Pheatmax);
strok=['n_{avg}/n_G<',num2str(n0max),', Q>',num2str(Qmin),...
    ', P_{fus}>',num2str(Pfusmin),'MW, P_{heat}<',num2str(Pheatmax),'MW'];

fok=0.*xx+NaN; fok(ind)=1;
plot(xx(ind),yy(ind),'kx','markersize',3); hold on;

% y00=1.5e20; % m^-3
% x00=70; % keV

eval([inputstr{jscanx},'=x00;']);
eval([inputstr{jscany},'=y00;']);


[Eth,H98,HST,Pheat,Pn,Pfus,Pwall,Qfus,betaN,betaT,nbar_o_nGw,q,...
    Pbrem,Pcycl,Vp,betap,fTavg,fnavg,Sp,ne0,M]=...
    funsc(R0,A,kappa,delta,Sn,ST,ni0,Ti0,fT,fsig,...
    f1,BT0,Ip,tauE,fHe,fimp,Zimp,Rw,g,icase);
        
str00='';

pltd=1;
if(pltd==1)
    plot(x00,y00,'rp','markersize',13,'markerfacecolor','y'); hold on;
    str00=[', P_{heat}=',num2str(Pheat,3),'MW, P_{fus}=',num2str(Pfus,3),...
        'MW, P_{brem}=',num2str(Pbrem,3),'MW, P_{cycl}=',num2str(Pcycl,3),...
        'MW, E_{th}=',num2str(Eth,3),...
        'MJ, n_{e0}=',num2str(ne0,3),'m^{-3},',10,...
        'Q_{fus}=',num2str(Qfus,2),', H_{98}=',num2str(H98,3),...
        ', H_{ST}=',num2str(HST,3),...
        ', \beta_N=',num2str(betaN,3),', V_p=',num2str(Vp,3),...
        'm^{3}, S_p=',num2str(Sp,3),'m^2, n_{avg}/n_G=',num2str(nbar_o_nGw,2),...
        ', q=',num2str(q,3),', \beta_T=',num2str(betaT*100,2),'%'];
end

xlabel([inputlabel{jscanx},', Best region: ',strok]);
ylabel([inputlabel{jscany},str00],'FontSize',12);
legend('P_{fus}','n_{avg}/n_G','Q','\beta_T','\beta_N','P_{heat}','H_{98}',...
    'H_{ST}','Best region','Selected ');
% legend('P_{fus}','n_{avg}/n_G','Q','\beta_T','\beta_N','P_{heat}','H_{98}',...
%     'Best region','Selected');%legend('boxoff');
strcase={'DT','DD','DHe3','pB-Nevins','pB-Sikora'};
title(['POPCON (',inputstr{jscanx},',',inputstr{jscany},...
    '), icase=',num2str(icase),'(',strcase{icase},'), n_{i0}=',num2str(ni0,3),...
    'm^{-3}, T_{i0}=',num2str(Ti0,3),'keV, R_0=',num2str(R0),...
    'm, A=',num2str(A),', B_0=',num2str(BT0),'T,',10,...
    '\delta=',num2str(delta),', \kappa=',num2str(kappa),', \tau_E=',num2str(tauE),...
    's, I_p=',num2str(Ip),'MA, S_n=',num2str(Sn,2),', S_T=',num2str(ST,2),...
    ', f_{Tavg}=',num2str(fTavg,2),', f_{navg}=',num2str(fnavg,2),...
    ',',10,'f_{T}=',num2str(fT,3),', f_{\sigma}=',num2str(fsig,3),...
    ', f_{1}=',num2str(f1,3),', f_{He}=',num2str(fHe,2),', f_{imp}=',num2str(fimp,2),...
    ', Z_{imp}=',num2str(Zimp,3),', R_{w}=',num2str(Rw,2),...
    ', g=',num2str(g,2),'m'],'FontSize',12);

% save figure
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);

prtstr=['figscan2d_sc_enn_icase=',num2str(icase),...
    ',jscanx=',num2str(jscanx),',jscany=',num2str(jscany),...
    ',kappa=',num2str(kappa),',delta=',num2str(delta),...
    ',R0=',num2str(R0,3),',A=',num2str(A,3),...
    ',ni0=',num2str(ni0,3),',Ti0=',num2str(Ti0,3),',BT0=',num2str(BT0),...
    ',Ip=',num2str(Ip),',tauE=',num2str(tauE),...
    ',Sn=',num2str(Sn),',ST=',num2str(ST),',pltd=',num2str(pltd)];
print(gcf,'-dpng',[prtstr,'.png']);
% print(gcf,'-dpdf',[prtstr,'.pdf']);
print(gcf,'-depsc',[prtstr,'.eps']);
